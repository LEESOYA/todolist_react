import React, { Component } from 'react';
import './todoList.css'

class Todolist extends Component {

  handleClick = () => {
    
  }

  render() {
    return (
      <ul className="todo-list">
        {this.props.todos.map(item => 
          <li 
            className="todo-item" 
            key={item.id}
            onClick={this.handleClick}
            >
            {/* <div>&times;</div> */}
            <span>{item.text}</span>
          </li>
        )}
      </ul>
    );
  }
}

export default Todolist;