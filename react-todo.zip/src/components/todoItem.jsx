import React, { Component } from 'react';
import './todoItem.css';

class TodoItem extends Component {
  render() {
    return (
      <div>
        
      </div>
    );
  }
}

export default TodoItem;